<?php
// DB 연결 파일 불러오기 (이전에 설정한 db.php)
include 'db.php'; 

try {
    // 💡 아래의 쿼리문을 로컬에서 사용하시던 스키마(구조)에 맞게 꼭 수정해 주세요!
    $sql = "CREATE TABLE customers (
        customer_id INT AUTO_INCREMENT PRIMARY KEY,
        user_type ENUM('학생', '직원') NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        gender ENUM('남', '녀') NOT NULL,
        age INT NOT NULL
    )";
    
    // 쿼리 실행
    $pdo->exec($sql);
    echo "🎉 customers 테이블이 성공적으로 생성되었습니다!";

} catch(PDOException $e) {
    echo "❌ 테이블 생성 실패: " . $e->getMessage();
}
?>