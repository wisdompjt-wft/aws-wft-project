<?php
// db.php - 로컬 PC 테스트용 설정
$host = '127.0.0.1';       // 로컬 호스트 IP (또는 'localhost')
$user = 'root';            // 로컬 MySQL 기본 관리자 아이디
$pass = '1234'; // MySQL 설치할 때 설정한 비밀번호
$db   = 'wft';   // users 테이블을 생성한 DB 이름
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // 로컬 디버깅을 위해 연결 실패 시 에러 메시지를 브라우저나 콘솔에 출력합니다.
    echo json_encode(['success' => false, 'message' => '로컬 DB 연결 실패: ' . $e->getMessage()]);
    exit;
}
?>