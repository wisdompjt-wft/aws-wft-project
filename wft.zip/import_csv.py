import csv
import math
import json
import os
import mysql.connector
from google import genai
import google.genai.errors
from dotenv import load_dotenv
import time
import boto3


def get_gemini_api_key():
    try:
        ssm = boto3.client('ssm', region_name='ap-northeast-2')
        response = ssm.get_parameter(Name='apikey', WithDecryption=True)
        return response['Parameter']['Value']
    except Exception as e:
        print(f"🚨 AWS 키 호출 실패: {e}")
        exit()

client = genai.Client(api_key=get_gemini_api_key())


conn = mysql.connector.connect( ## 수정해서 사용
    host="localhost",
    user="root",
    password="1234",
    database="wft",
    port=2102
)
cursor = conn.cursor()


# 3. CSV 파일 읽어서 AI가 태그 달고 DB에 넣기
csv_file_path = 'real_foods.csv'
print(f"{csv_file_path} 파일에서 음식 정보를 읽어와 AI 작업을 시작합니다...\n")

with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile) 
    
    for row in reader:
        store_id = row['store_id']
        food_name = row['food_name']
        price = row['price'] 
        food_image_url = row['food_image_url']
        recommend_reason = row.get('recommend_reason', '') 
        
        # 💡 이미 DB에 저장되어 있는 음식인지 확인 (이어받기 기능)
        check_query = "SELECT COUNT(*) FROM foods WHERE store_id = %s AND food_name = %s"
        cursor.execute(check_query, (store_id, food_name))
        (exists_count,) = cursor.fetchone()
        
        if exists_count > 0:
            print(f"⏭️ [{food_name}] 이미 DB에 존재하므로 건너뜁니다.")
            continue
            
        # --- 여기서부터 새로운 음식만 AI 작업 진행 ---
        prompt = f"""You are a food recommendation expert. 
Generate exactly 5 core keywords describing the taste, ingredients, characteristics, and best pairings for the food: '{food_name}'.
The keywords MUST be in Korean. 
Output ONLY the 5 keywords separated by commas, with no additional text, greeting, or explanation.

Example for '제육볶음': 매콤달콤한,불맛,돼지고기,든든한,밥
Output for '{food_name}':"""
        
        # 💡 [안전장치 오토루프] 429 에러가 발생하면 여기서 걸러내어 60초를 쉬게 만듭니다.
        while True:
            try:
                # 1) AI 태그 생성
                tag_response = client.models.generate_content(
                    model='gemini-2.0-flash-lite',
                    contents=prompt
                )
                ai_generated_tags = tag_response.text.strip()
                
                # 2) AI 임베딩 벡터 추출
                embed_response = client.models.embed_content(
                    model='gemini-embedding-001', 
                    contents=ai_generated_tags
                )
                vector = embed_response.embeddings[0].values
                
                # 둘 다 에러 없이 성공했다면 루프 탈출!
                break
                
            except google.genai.errors.ClientError as e:
                # 구글 API 한도 초과(429) 에러가 발생한 경우
                if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e):
                    print(f"\n🛑 [안내] '{food_name}' 처리 중 구글 API 분당 한도 초과(429)가 발생했습니다.")
                    print("⏰ 60초 동안 안전하게 대기한 후 자동으로 이어서 시작합니다. 잠시만 기다려주세요...")
                    time.sleep(60) # 1분 휴식
                    print("🔄 대기 종료! 다시 작업을 재개합니다.\n")
                else:
                    # 429 외의 다른 원인의 에러라면 그대로 프로그램 중지 후 에러 출력
                    raise e 

        print(f"🆕 [{food_name}] AI 태그 생성 완료: {ai_generated_tags}")
        
        # 768차원 자르기 및 L2 정규화
        truncated_vector = vector[:768]
        magnitude = math.sqrt(sum(x**2 for x in truncated_vector))
        normalized_vector = [x / magnitude for x in truncated_vector]
        
        vector_str = json.dumps(normalized_vector)
        
        # DB 저장
        insert_query = """
            INSERT INTO foods (store_id, food_name, food_image_url, price, recommend_reason, ai_generated_tags, embedding) 
            VALUES (%s, %s, %s, %s, %s, %s, VEC_FromText(%s))
        """
        cursor.execute(insert_query, (store_id, food_name, food_image_url, price, recommend_reason, ai_generated_tags, vector_str))
        print(f"   ➔ DB 저장 완료!\n")
        
        # 안전한 진행을 위해 주기적으로 4.5초씩 쉬어줍니다.
        time.sleep(4.5) 

conn.commit()
cursor.close()
conn.close()

print("✨ 모든 음식 데이터와 AI 벡터가 완벽하게 동기화되어 저장되었습니다!")