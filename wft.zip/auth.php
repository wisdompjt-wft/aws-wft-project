<?php
// auth.php
header('Content-Type: application/json');
require_once 'db.php';
session_start();

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// [회원가입] user_type, email, password, gender, age 저장
if ($action === 'register') {
    // 💡 프론트에서 보낸 user_type 추가로 받기
    $userType = trim($input['user_type'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = trim($input['password'] ?? '');
    $gender = trim($input['gender'] ?? '');
    $age = isset($input['age']) ? intval($input['age']) : 0;

    // 💡 빈 값 검증에 $userType 추가
    if (!$userType || !$email || !$password || !$gender || !$age) {
        echo json_encode(['success' => false, 'message' => '모든 항목을 입력해주세요.']);
        exit;
    }
    
    // === 💡 학생/직원 여부 서버 측 검증 추가 ===
    if (!in_array($userType, ['학생', '직원'])) {
        echo json_encode(['success' => false, 'message' => '학생 또는 직원 여부 입력이 올바르지 않습니다.']);
        exit;
    }

    // === 이메일 형식 서버 측 검증 추가 ===
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => '올바른 이메일 형식이 아닙니다.']);
        exit;
    }

    if (!in_array($gender, ['남', '녀'])) {
        echo json_encode(['success' => false, 'message' => '성별 입력이 올바르지 않습니다.']);
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        // 💡 INSERT 쿼리와 execute 배열에 user_type 추가
        $stmt = $pdo->prepare("INSERT INTO customers (user_type, email, password, gender, age) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$userType, $email, $hashedPassword, $gender, $age]);
        echo json_encode(['success' => true, 'message' => '회원가입이 완료되었습니다!']);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { 
            echo json_encode(['success' => false, 'message' => '이미 가입된 이메일 주소입니다.']);
        } else {
            echo json_encode(['success' => false, 'message' => '회원가입 중 오류가 발생했습니다.']);
        }
    }
}

// [로그인] email을 ID로 사용하여 로그인 처리
elseif ($action === 'login') {
    $email = trim($input['email'] ?? '');
    $password = trim($input['password'] ?? '');

    $stmt = $pdo->prepare("SELECT * FROM customers WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['customer_id'] = $user['customer_id'];
        $_SESSION['email'] = $user['email'];
        echo json_encode(['success' => true, 'message' => '로그인 성공', 'email' => $user['email']]);
    } else {
        echo json_encode(['success' => false, 'message' => '이메일 또는 비밀번호가 일치하지 않습니다.']);
    }
}

// [아이디(이메일) 찾기] 성별과 나이가 일치하는 이메일 조회
elseif ($action === 'find_id') {
    $gender = trim($input['gender'] ?? '');
    $age = isset($input['age']) ? intval($input['age']) : 0;

    if (!$gender || !$age) {
        echo json_encode(['success' => false, 'message' => '성별과 나이를 모두 입력해주세요.']);
        exit;
    }

    try {
        // 입력한 성별과 나이에 맞는 회원의 이메일을 조회
        $stmt = $pdo->prepare("SELECT email FROM customers WHERE gender = ? AND age = ?");
        $stmt->execute([$gender, $age]);
        $user = $stmt->fetch();

        if ($user) {
            echo json_encode(['success' => true, 'message' => "찾으시는 이메일(아이디)은 [ " . $user['email'] . " ] 입니다."]);
        } else {
            echo json_encode(['success' => false, 'message' => '일치하는 회원 정보가 없습니다.']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => '조회 중 오류가 발생했습니다.']);
    }
}

// [비밀번호 찾기/초기화] 이메일과 나이가 일치하는지 검증 후 초기화
elseif ($action === 'find_pw') {
    $email = trim($input['email'] ?? '');
    $age = isset($input['age']) ? intval($input['age']) : 0;

    $stmt = $pdo->prepare("SELECT customer_id FROM customers WHERE email = ? AND age = ?");
    $stmt->execute([$email, $age]);
    $user = $stmt->fetch();

    if ($user) {
        $temporaryPassword = 'whatfood1234!';
        $hashedPassword = password_hash($temporaryPassword, PASSWORD_DEFAULT);
        
        $updateStmt = $pdo->prepare("UPDATE customers SET password = ? WHERE customer_id = ?");
        $updateStmt->execute([$hashedPassword, $user['customer_id']]);
        
        echo json_encode(['success' => true, 'message' => "비밀번호가 [ $temporaryPassword ] 로 초기화되었습니다. 로그인 후 변경해 주세요."]);
    } else {
        echo json_encode(['success' => false, 'message' => '일치하는 고객 정보가 없습니다. 나이를 정확히 입력했는지 확인해 주세요.']);
    }
}

// [비밀번호 변경] 로그인된 세션의 customer_id를 사용
elseif ($action === 'change_pw') {
    if (!isset($_SESSION['customer_id'])) {
        echo json_encode(['success' => false, 'message' => '로그인이 필요합니다.']);
        exit;
    }

    $newPassword = trim($input['new_password'] ?? '');

    if (strlen($newPassword) < 4) {
        echo json_encode(['success' => false, 'message' => '비밀번호는 최소 4자 이상이어야 합니다.']);
        exit;
    }

    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $customerId = $_SESSION['customer_id'];

    try {
        $stmt = $pdo->prepare("UPDATE customers SET password = ? WHERE customer_id = ?");
        $stmt->execute([$hashedPassword, $customerId]);
        echo json_encode(['success' => true, 'message' => '비밀번호가 성공적으로 변경되었습니다!']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => '변경 중 오류가 발생했습니다.']);
    }
}

// [로그아웃] 세션 완전 파괴
elseif ($action === 'logout') {
    // 모든 세션 변수 해제
    session_unset();
    // 세션 파괴
    session_destroy();
    
    echo json_encode(['success' => true, 'message' => '정상적으로 로그아웃 되었습니다.']);
    exit;
}
?>