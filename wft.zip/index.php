<?php 
session_start(); 
require_once 'db.php'; // db.php를 불러오기

// 로그인 세션이 이미 존재하면 프론트엔드에 상태를 넘겨주기 위한 처리
$isLoggedIn = isset($_SESSION['customer_id']) ? 'true' : 'false';
$userEmail = isset($_SESSION['email']) ? $_SESSION['email'] : '';

// 1. DB에서 진짜 음식 데이터 가져오기
$stmtFoods = $pdo->query("SELECT * FROM foods");
$realFoods = $stmtFoods->fetchAll(PDO::FETCH_ASSOC);

// 2. DB에서 진짜 가게 데이터 가져오기 (JS에서 쓰기 편하게 store_id를 키값으로 정리)
$stmtStores = $pdo->query("SELECT * FROM stores");
$stores = $stmtStores->fetchAll(PDO::FETCH_ASSOC);
$realStores = [];
foreach ($stores as $store) {
    $realStores[$store['store_id']] = $store;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>whatfood.today - 단 하나의 메뉴 추천</title>
    <style>
        body {
            font-family: 'Malgun Gothic', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7f6;
            color: #333;
            overflow-x: hidden; /* 슬라이드 침범 방지 */
        }

        .hidden { display: none !important; }

        /* === 로그인 & 인증 상자 스타일 === */
        .auth-container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 340px;
            text-align: center;
        }
        .login-box h1 { margin-top: 0; color: #ff6b6b; }
        .login-box h2 { font-size: 14px; margin-bottom: 20px; color: #777; }
        .login-box input, .login-box select {
            width: 90%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .login-box button {
            width: 100%;
            padding: 12px;
            background-color: #ff6b6b;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 10px;
            font-size: 15px;
        }
        .login-box button:hover { background-color: #ff5252; }
        .login-links { margin-top: 15px; font-size: 13px; }
        .login-links a { color: #555; text-decoration: none; margin: 0 5px; cursor: pointer; }
        .login-links a:hover { text-decoration: underline; color: #ff6b6b; }

        /* === 90% 꽉 차는 메인 서비스 레이아웃 === */
        #main-page { 
            width: 90%; 
            max-width: 1600px; 
            margin: 0 auto; 
            padding: 30px 0;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px solid #ff6b6b;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
            cursor: pointer;
            user-select: none;
        }
        .header-logo { height: 50px; width: auto; object-fit: contain; }
        header h1 { margin: 0; color: #ff6b6b; font-size: 32px; font-weight: 800; letter-spacing: -1px; }
        .user-area { display: flex; align-items: center; gap: 15px; font-size: 16px; }
        .user-area button { padding: 8px 16px; font-size: 14px; border-radius: 6px; cursor: pointer; }

        /* === 메인 콘텐츠 배치 워크스페이스 === */
        .workspace {
            display: flex;
            flex-direction: column;
            gap: 30px;
            width: 100%;
        }

        /* 💡 [핵심] 상단 가로 정렬 영역 */
        .interactive-showcase {
            display: flex;
            width: 100%;
            align-items: flex-start;
            justify-content: center;
            gap: 20px;
            position: relative;
        }

        /* 중앙 추천 음식 카드 */
        .food-card-center {
            flex: 0 0 550px; /* 크기 고정 */
            z-index: 10;
        }
        .food-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0,0,0,0.12);
            text-align: center;
            width: 100%;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .food-card:hover { transform: translateY(-5px); box-shadow: 0 20px 40px rgba(0,0,0,0.18); }
        .food-card img { width: 100%; height: 350px; object-fit: cover; }
        .food-info { padding: 25px; }
        .food-title { font-size: 28px; font-weight: bold; margin: 0 0 10px 0; color: #111; }
        .food-notes { font-size: 15px; color: #666; margin-bottom: 15px; font-style: italic; }
        .food-price { font-size: 22px; color: #ff6b6b; font-weight: bold; }
        .click-hint { font-size: 13px; color: #999; margin-top: 12px; display: block; text-decoration: underline; }

        /* 💡 양측 슬라이드 섹션 공통 스타일 */
        .side-panel {
            flex: 1;
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            box-sizing: border-box;
            height: 520px; /* 음식 카드 높이와 균형 유지 */
            display: flex;
            flex-direction: column;
            
            /* 슬라이드 애니메이션 세팅 */
            opacity: 0;
            visibility: hidden;
            transition: all 0.4s ease-in-out;

            min-width: 0;
        }

        /* 왼쪽 메뉴판 좌측 슬라이드 효과 */
        .side-panel.left-slide { transform: translateX(50px); }
        /* 오른쪽 정보 우측 슬라이드 효과 */
        .side-panel.right-slide { transform: translateX(-50px); }

        /* 활성화 되었을 때 나타나는 상태 */
        .side-panel.active {
            opacity: 1;
            visibility: visible;
            transform: translateX(0);
        }

        /* 왼쪽 내용 상세 */
        .menu-board-section h3 { margin-top: 0; font-size: 18px; color: #444; border-bottom: 2px solid #eee; padding-bottom: 10px; }
        .menu-board-img { 
            width: 100%; height: 100%; max-height: 420px; object-fit: contain; 
            background: #fafafa; border-radius: 10px; border: 1px solid #e0e0e0; 
            cursor: zoom-in; /* 💡 마우스를 올리면 돋보기 모양으로 변함 */
        }

        /* 오른쪽 내용 상세 */
        .store-title { font-size: 24px; font-weight: bold; margin: 0 0 8px 0; color: #ff6b6b; }
        .store-loc { font-size: 15px; color: #555; margin: 0 0 20px 0; display: flex; align-items: center; gap: 5px; }
        .store-loc a { color: #0068c3; text-decoration: none; font-weight: 500; }
        .store-loc a:hover { text-decoration: underline; color: #004d91; }
        
        .reason-box {
            background: #f0f8ff; padding: 15px; border-radius: 8px; font-size: 14px; color: #333; margin-bottom: 15px; border-left: 4px solid #4facfe; line-height: 1.5; 

            word-break: keep-all; 
            overflow-wrap: break-word;
        }
        .store-notes {
            background: #fff5f5; padding: 15px; border-radius: 8px; font-size: 14px; color: #cb3838; margin-bottom: 15px; border-left: 4px solid #ff6b6b; line-height: 1.5; 

            word-break: keep-all; 
            overflow-wrap: break-word;
        }

        /* 💡 하단에 안정적으로 깔리는 OpenAI 채팅창 영역 */
        .ai-chat-placeholder {
            width: 100%;
            background: #fff;
            border: 2px dashed #ff6b6b;
            border-radius: 12px;
            padding: 25px;
            text-align: center;
            font-weight: bold;
            color: #ff6b6b;
            font-size: 18px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
            box-sizing: border-box;
            margin-top: 10px;
        }
        .test-trigger-btn { background: #ff6b6b; color: white; border: none; padding: 10px 20px; font-size: 15px; font-weight: bold; border-radius: 6px; cursor: pointer; margin-top: 12px; }
        .test-trigger-btn:hover { background: #ff5252; }

        /* 💡 창이 작아졌을 때 상하(세로) 배치로 바꿔주는 반응형 코드 (공백 제거 완벽 적용) */
        @media screen and (max-width: 1100px) {
            .interactive-showcase {
                flex-direction: column;
                align-items: center;
            }
            
            /* 1. 음식 카드를 무조건 맨 위(1순위)로 끌어올림 */
            .food-card-center {
                flex: none;
                width: 100%;
                max-width: 500px;
                order: 1; /* ★ 순서를 1번으로 강제 지정 */
            }
            
            /* 2. 왼쪽 패널은 2번, 오른쪽 패널은 3번으로 밑에 배치 */
            #left-panel { order: 2; }
            #right-panel { order: 3; }

            .side-panel {
                width: 100%;
                max-width: 500px;
                height: auto;
                
                /* 3. ★ 핵심: 안 보일 때 투명하게 공간만 차지하는 걸 막기 위해 아예 흔적을 없앰 */
                display: none; 
            }
            
            /* 4. 메뉴 사진을 눌러서 active 클래스가 붙으면 아래쪽에 짠! 하고 나타나게 함 */
            .side-panel.active {
                display: flex; 
                margin-top: 20px; 
                transform: none; /* 모바일에서는 슬라이드 이동 효과 제거 */
                opacity: 1;
            }
        }
    </style>
</head>
<body>

    <div id="auth-zone" class="auth-container">
        <div id="login-box" class="login-box">
            <h1>whatfood</h1>
            <p>오늘 뭐 먹지?</p>
            <input type="email" id="login-email" placeholder="이메일 주소" required>
            <input type="password" id="login-pw" placeholder="비밀번호" required>
            <button onclick="attemptLogin()">로그인</button>
            <div class="login-links">
                <a onclick="switchAuthView('register')">회원가입</a> | 
                <a onclick="switchAuthView('find-id')">아이디 찾기</a> |
                <a onclick="switchAuthView('find-pw')">비밀번호 찾기</a>
            </div>
        </div>

        <div id="register-box" class="login-box hidden">
            <h1>회원가입</h1>
            
            <div style="display: flex; justify-content: center; gap: 40px; margin: 15px 0; color: #555; font-size: 15px;">
                <label style="cursor: pointer; display: flex; align-items: center; gap: 8px;">
                    <input type="radio" name="reg-type" value="학생" style="width: auto; margin: 0; padding: 0;"> 🎓 학생
                </label>
                <label style="cursor: pointer; display: flex; align-items: center; gap: 8px;">
                    <input type="radio" name="reg-type" value="직원" style="width: auto; margin: 0; padding: 0;"> 💼 직원
                </label>
            </div>
            <input type="email" id="reg-email" placeholder="이메일 주소" required>
            <input type="password" id="reg-pw" placeholder="비밀번호 (4자리 이상)" required>
            <select id="reg-gender" required>
                <option value="" disabled selected>성별 선택</option>
                <option value="남">남자</option>
                <option value="녀">여자</option>
            </select>
            <input type="number" id="reg-age" placeholder="태어난 년도 (숫자만)" min="1" max="150" required>
            <button onclick="attemptRegister()">가입하기</button>
            <div class="login-links"><a onclick="switchAuthView('login')">이전으로 돌아가기</a></div>
        </div>

        <div id="find-id-box" class="login-box hidden">
            <h1>아이디 찾기</h1>
            <h2>성별과 태어난 년도를 입력해 주세요</h2>
            <select id="find-id-gender" required>
                <option value="" disabled selected>성별 선택</option>
                <option value="남">남자</option>
                <option value="녀">여자</option>
            </select>
            <input type="number" id="find-id-age" placeholder="가입 시 입력한 태어난 년도" min="1" max="150" required>
            <button onclick="attemptFindId()">아이디 찾기</button>
            <div class="login-links"><a onclick="switchAuthView('login')">이전으로 돌아가기</a></div>
        </div>

        <div id="find-pw-box" class="login-box hidden">
            <h1>비밀번호 찾기</h1>
            <h2>가입한 이메일과 태어난 년도를 입력해 주세요</h2>
            <input type="email" id="find-pw-email" placeholder="이메일 주소" required>
            <input type="number" id="find-pw-age" placeholder="가입 시 입력한 태어난 년도" required>
            <button onclick="attemptFindPw()">비밀번호 초기화</button>
            <div class="login-links"><a onclick="switchAuthView('login')">이전으로 돌아가기</a></div>
        </div>
    </div>

    <div id="main-page" class="hidden">
        <header>
            <div class="logo-container" onclick="location.reload()">
                <img src="logo_bg_remove.png" alt="whatfood 로고" class="header-logo">
                <h1>whatfood.today</h1>
            </div>
            <div class="user-area">
                <span id="user-welcome" style="font-weight:bold; color: #555;"></span>
                <button onclick="toggleChangePwView(true)" style="border: 1px solid #ddd; background: white; border-radius: 5px;">비밀번호 변경</button>
                <button onclick="logout()" style="border: none; background: #ff6b6b; color: white; font-weight: bold;">로그아웃</button>
            </div>
        </header>

        <div class="workspace">
            
            <div class="interactive-showcase">
                
                <div id="left-panel" class="side-panel left-slide">
                    <div class="menu-board-section">
                        <h3 id="board-title">📋 가게 - 전체 메뉴판</h3>
                        <img id="board-img" src="" class="menu-board-img" alt="가게 메뉴판">
                    </div>
                </div>

                <div class="food-card-center">
                    <div id="food-card-target" class="food-card" onclick="toggleSidePanels()">
                        </div>
                </div>

                <div id="right-panel" class="side-panel right-slide">
                    <h2 id="store-title" class="store-title">가게 이름</h2>
                    
                    <p class="store-loc">
                        📍 지도: <a id="store-url" href="#" target="_blank" style="font-weight: bold;"></a>
                    </p>
                    
                    <div id="ai-reason" class="reason-box">추천 이유</div>
                    
                    <div id="store-notes" class="store-notes">특이사항</div>
                </div>

            </div>

            <div class="ai-chat-placeholder">
                💬 [AI 추천 메뉴] <br>
                <span style="font-size:14px; font-weight:normal; color:#888;">이 섹션은 OpenAI 연동 팀원이 채팅창 인터페이스를 올릴 예정입니다.</span><br>
                <button class="test-trigger-btn" onclick="simulateAiRecommendation()">🎲 임시 AI 추천 결과 받기 테스트</button>
            </div>

        </div>
    </div>

    <div id="change-pw-zone" class="hidden" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999; display:flex; align-items:center; justify-content:center;">
        <div class="login-box" style="width:350px;">
            <h1>비밀번호 변경</h1>
            <p>새로 사용할 비밀번호를 입력하세요.</p>
            <input type="password" id="new-pw-input" placeholder="새 비밀번호" required>
            <input type="password" id="new-pw-confirm" placeholder="새 비밀번호 확인" required>
            <button onclick="attemptChangePw()">변경하기</button>
            <button onclick="toggleChangePwView(false)" style="background:#999; margin-top:5px;">취소</button>
        </div>
    </div>

    <div id="image-zoom-modal" class="hidden" onclick="closeZoomModal()" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; display:flex; align-items:center; justify-content:center; cursor:zoom-out;">
        <img id="zoomed-img" src="" style="max-width:90%; max-height:90%; object-fit:contain; border-radius:10px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
    </div>

    <script>
        // PHP 백엔드 세션 감지 상태 변수
        const IS_LOGGED_IN_SERVER = <?php echo $isLoggedIn; ?>;
        const SERVER_USER_EMAIL = "<?php echo $userEmail; ?>";

        // S3 버킷 기본 주소를 선언 (끝에 꼭 슬래시 / 를 붙이기)
        const S3_BASE_URL = "<?php echo S3_BASE_URL; ?>";

        // 문서 로드 시 세션이 있으면 즉시 메인 화면 로출 (F5 새로고침 방어방벽)
        window.addEventListener('DOMContentLoaded', () => {
            if(IS_LOGGED_IN_SERVER) {
                document.getElementById('auth-zone').classList.add('hidden');
                document.getElementById('main-page').classList.remove('hidden');
                document.getElementById('user-welcome').innerText = `${SERVER_USER_EMAIL}님 환영합니다!`;
                simulateAiRecommendation(); 
            }
        });

        const storesData = <?php echo json_encode($realStores); ?>;
        const foodsData = <?php echo json_encode($realFoods); ?>;

        window.currentFood = null;
        window.currentStore = null;

        // 창 전환 함수
        function switchAuthView(viewName) {
            document.getElementById('login-box').classList.add('hidden');
            document.getElementById('register-box').classList.add('hidden');
            document.getElementById('find-id-box').classList.add('hidden');
            document.getElementById('find-pw-box').classList.add('hidden');

            if(viewName === 'login') document.getElementById('login-box').classList.remove('hidden');
            if(viewName === 'register') document.getElementById('register-box').classList.remove('hidden');
            if(viewName === 'find-id') document.getElementById('find-id-box').classList.remove('hidden');
            if(viewName === 'find-pw') document.getElementById('find-pw-box').classList.remove('hidden');
        }

        // 아이디 찾기 통신 함수
        async function attemptFindId() {
            const gender = document.getElementById('find-id-gender').value;
            const age = document.getElementById('find-id-age').value;
            if(!gender || !age) { alert('성별과 태어난 년도를 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'find_id', gender: gender, age: age })
            });
            const res = await response.json();
            alert(res.message);
            if(res.success) { switchAuthView('login'); }
        }

        // 비밀번호 찾기 통신 함수
        async function attemptFindPw() {
            const email = document.getElementById('find-pw-email').value;
            const age = document.getElementById('find-pw-age').value;
            if(!email || !age) { alert('이메일과 태어난 년도를 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'find_pw', email: email, age: age })
            });
            const res = await response.json();
            alert(res.message);
        }

        async function attemptLogin() {
            const email = document.getElementById('login-email').value;
            const pw = document.getElementById('login-pw').value;
            if(!email || !pw) { alert('이메일과 비밀번호를 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'login', email: email, password: pw })
            });
            const res = await response.json();
            
            if(res.success) {
                // 로그인 성공 시 강제 새로고침을 통해 PHP 세션 상태 동기화 바인딩
                location.reload();
            } else {
                alert(res.message);
            }
        }

        async function attemptRegister() {
            const typeRadio = document.querySelector('input[name="reg-type"]:checked');
            const userType = typeRadio ? typeRadio.value : null;

            const email = document.getElementById('reg-email').value.trim();
            const pw = document.getElementById('reg-pw').value;
            const gender = document.getElementById('reg-gender').value;
            const age = document.getElementById('reg-age').value;

            if(!userType) { alert('학생인지 직원인지 선택해주세요.'); return; }
            if(!email || !pw || !gender || !age) { alert('모든 항목을 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    action: 'register', 
                    user_type: userType, 
                    email: email, 
                    password: pw, 
                    gender: gender, 
                    age: age 
                })
            });
            const res = await response.json();
            alert(res.message);
            if(res.success) { switchAuthView('login'); }
        }

        // 로그아웃 시 서버 세션 파괴 요청 후 리로드
        async function logout() {
            await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'logout' }) 
            });
            location.reload();
        }

        // 팝업창 열고 닫는 함수
        function toggleChangePwView(show) {
            const zone = document.getElementById('change-pw-zone');
            if(show) { 
                zone.classList.remove('hidden'); 
                zone.style.display = 'flex'; 
            } else { 
                zone.classList.add('hidden'); 
                zone.style.display = 'none'; 
            }
        }

        // 서버(auth.php)로 변경 요청 보내는 함수
        async function attemptChangePw() {
            const newPw = document.getElementById('new-pw-input').value;
            const confirmPw = document.getElementById('new-pw-confirm').value;
            
            if(!newPw || !confirmPw) { alert('비밀번호를 입력해주세요.'); return; }
            if(newPw !== confirmPw) { alert('비밀번호가 일치하지 않습니다.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'change_pw', new_password: newPw })
            });
            const res = await response.json();
            
            alert(res.message);
            if(res.success) { 
                toggleChangePwView(false);
                document.getElementById('new-pw-input').value = '';
                document.getElementById('new-pw-confirm').value = '';
            }
        }

        // AI 추천 생성 엔진 실행시 정보 주입
        function simulateAiRecommendation() {
            const randomIndex = Math.floor(Math.random() * foodsData.length);
            const food = foodsData[randomIndex];
            const store = storesData[food.store_id];

            window.currentFood = food;
            window.currentStore = store;

            const fullFoodImageUrl = S3_BASE_URL + food.food_image_url;

            const targetBox = document.getElementById('food-card-target');
            targetBox.innerHTML = `
                <img src="${fullFoodImageUrl}" alt="${food.food_name}">
                <div class="food-info">
                    <h2 class="food-title">${store.store_name}<br>추천 메뉴 : ${food.food_name}</h2>
                    <div class="food-price">${Number(food.price).toLocaleString()} 원</div>
                    <span class="click-hint">🔍 메뉴 사진을 클릭하면 좌우로 상세 정보가 열립니다!</span>
                </div>
            `;
            
            syncSidePanelsData();
            // 새 추천을 받으면 양 옆 슬라이드는 초기화(닫힘) 처리
            document.getElementById('left-panel').classList.remove('active');
            document.getElementById('right-panel').classList.remove('active');
        }

        function syncSidePanelsData() {
            if(!window.currentFood || !window.currentStore) return;
            const store = window.currentStore;
            const food = window.currentFood;

            // 좌측: 메뉴판 세팅
            document.getElementById('board-title').innerText = `📋 ${store.store_name} - 메뉴판`;
            document.getElementById('board-img').src = S3_BASE_URL + store.store_menu_url;

            // 우측: 1. 상호
            document.getElementById('store-title').innerText = store.store_name;
            
            // 우측: 2. 지도 바로가기 링크 세팅
            const urlElem = document.getElementById('store-url');

            // 💡 1. 텍스트를 '[상호명] 바로가기'로 설정
            urlElem.innerText = `${store.store_name} 바로가기`; 

            // 💡 2. URL 링크 데이터를 store.location 에서 가져옴! (핵심)
            let linkUrl = store.location; 

            if (linkUrl && linkUrl.trim() !== "") {
                // 💡 3. http가 빠져있으면 붙여서 새창 열림(새로고침) 오류 방지
                if (!linkUrl.startsWith('http')) {
                    linkUrl = 'https://' + linkUrl;
                }
                urlElem.href = linkUrl;
                urlElem.onclick = null; // 정상 작동하도록 기존 클릭 차단 이벤트 해제
            } else {
                // 💡 4. 만약 DB에 지도 URL 자체가 비어있을 경우 새로고침 방어
                urlElem.href = "#";
                urlElem.onclick = function(e) {
                    e.preventDefault(); 
                    alert("아직 등록된 지도 링크가 없습니다.");
                };
            }
            
            // 우측: 3. 추천 이유
            document.getElementById('ai-reason').innerHTML = `<strong>💡 추천 이유:</strong><br>${food.recommend_reason}`;
            
            // 우측: 4. 꿀팁 (특이사항)
            document.getElementById('store-notes').innerHTML = `<strong>🍯 꿀팁:</strong><br>${store.ggultip}`;
        }

        // 메뉴 카드 클릭 시 좌우 패널 슬라이드 토글 함수
        function toggleSidePanels() {
            const leftPanel = document.getElementById('left-panel');
            const rightPanel = document.getElementById('right-panel');

            if(leftPanel.classList.contains('active')) {
                leftPanel.classList.remove('active');
                rightPanel.classList.remove('active');
            } else {
                syncSidePanelsData();
                leftPanel.classList.add('active');
                rightPanel.classList.add('active');
            }
        }

        // 💡 기존 메뉴판 이미지를 클릭했을 때 실행되는 이벤트
        document.getElementById('board-img').addEventListener('click', function() {
            const zoomModal = document.getElementById('image-zoom-modal');
            const zoomedImg = document.getElementById('zoomed-img');
            
            // 1. 현재 클릭한 작은 메뉴판의 이미지 주소(src)를 큼직한 모달창 이미지 주소로 복사
            zoomedImg.src = this.src; 
            
            // 2. 숨김 처리(hidden)를 해제하여 화면에 띄움
            zoomModal.classList.remove('hidden'); 
        });

        // 💡 확대된 상태에서 검은 배경이나 이미지를 다시 클릭했을 때 닫히는 함수
        function closeZoomModal() {
            document.getElementById('image-zoom-modal').classList.add('hidden');
        }
    </script>
</body>
</html>