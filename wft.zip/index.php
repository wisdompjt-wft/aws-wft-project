<?php 
session_start(); 
require_once 'db.php'; // db.php를 불러오기

// 로그인 세션이 이미 존재하면 프론트엔드에 상태를 넘겨주기 위한 처리
$isLoggedIn = isset($_SESSION['customer_id']) ? 'true' : 'false';
$userEmail = isset($_SESSION['email']) ? $_SESSION['email'] : '';

// 1. DB에서 진짜 음식 데이터 가져오기
$stmtFoods = $pdo->query("SELECT food_id, store_id, food_name, food_image_url, price, recommend_reason, ai_generated_tags FROM foods");
$realFoods = $stmtFoods->fetchAll(PDO::FETCH_ASSOC);

// 2. DB에서 진짜 가게 데이터 가져오기 (JS에서 쓰기 편하게 store_id를 키값으로 정리)
$stmtStores = $pdo->query("SELECT * FROM stores");
$stores = $stmtStores->fetchAll(PDO::FETCH_ASSOC);
$realStores = [];
foreach ($stores as $store) {
    $realStores[$store['store_id']] = $store;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>whatfood.today - 단 하나의 메뉴 추천</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div id="auth-zone" class="auth-container">
        <div id="login-box" class="login-box">
            <h1>whatfood</h1>
            <p>오늘 뭐 먹지?</p>
            <input type="email" id="login-email" placeholder="이메일 주소" required>
            <input type="password" id="login-pw" placeholder="비밀번호" required>
            <button onclick="attemptLogin()">로그인</button>
            <div class="login-links">
                <a onclick="switchAuthView('register')">회원가입</a> | 
                <a onclick="switchAuthView('find-id')">아이디 찾기</a> |
                <a onclick="switchAuthView('find-pw')">비밀번호 찾기</a>
            </div>
        </div>

        <div id="register-box" class="login-box hidden">
            <h1>회원가입</h1>
            
            <div style="display: flex; justify-content: center; gap: 40px; margin: 15px 0; color: #555; font-size: 15px;">
                <label style="cursor: pointer; display: flex; align-items: center; gap: 8px;">
                    <input type="radio" name="reg-type" value="학생" style="width: auto; margin: 0; padding: 0;"> 🎓 학생
                </label>
                <label style="cursor: pointer; display: flex; align-items: center; gap: 8px;">
                    <input type="radio" name="reg-type" value="직원" style="width: auto; margin: 0; padding: 0;"> 💼 직원
                </label>
            </div>
            <input type="email" id="reg-email" placeholder="이메일 주소" required>
            <input type="password" id="reg-pw" placeholder="비밀번호 (4자리 이상)" required>
            <select id="reg-gender" required>
                <option value="" disabled selected>성별 선택</option>
                <option value="남">남자</option>
                <option value="녀">여자</option>
            </select>
            <input type="number" id="reg-age" placeholder="태어난 년도 (숫자만)" min="1" max="150" required>
            <button onclick="attemptRegister()">가입하기</button>
            <div class="login-links"><a onclick="switchAuthView('login')">이전으로 돌아가기</a></div>
        </div>

        <div id="find-id-box" class="login-box hidden">
            <h1>아이디 찾기</h1>
            <h2>성별과 태어난 년도를 입력해 주세요</h2>
            <select id="find-id-gender" required>
                <option value="" disabled selected>성별 선택</option>
                <option value="남">남자</option>
                <option value="녀">여자</option>
            </select>
            <input type="number" id="find-id-age" placeholder="가입 시 입력한 태어난 년도" min="1" max="150" required>
            <button onclick="attemptFindId()">아이디 찾기</button>
            <div class="login-links"><a onclick="switchAuthView('login')">이전으로 돌아가기</a></div>
        </div>

        <div id="find-pw-box" class="login-box hidden">
            <h1>비밀번호 찾기</h1>
            <h2>가입한 이메일과 태어난 년도를 입력해 주세요</h2>
            <input type="email" id="find-pw-email" placeholder="이메일 주소" required>
            <input type="number" id="find-pw-age" placeholder="가입 시 입력한 태어난 년도" required>
            <button onclick="attemptFindPw()">비밀번호 초기화</button>
            <div class="login-links"><a onclick="switchAuthView('login')">이전으로 돌아가기</a></div>
        </div>
    </div>

    <div id="main-page" class="hidden">
        <header>
            <div class="logo-container" onclick="location.reload()">
                <img src="logo_bg_remove.png" alt="whatfood 로고" class="header-logo">
                <h1>whatfood.today</h1>
            </div>
            <div class="user-area">
                <span id="user-welcome" style="font-weight:bold; color: #555;"></span>
                <button onclick="toggleChangePwView(true)" style="border: 1px solid #ddd; background: white; border-radius: 5px;">비밀번호 변경</button>
                <button onclick="logout()" style="border: none; background: #ff6b6b; color: white; font-weight: bold;">로그아웃</button>
            </div>
        </header>

        <div class="workspace">
            
            <div class="interactive-showcase">
                
                <div id="left-panel" class="side-panel left-slide">
                    <div class="menu-board-section">
                        <h3 id="board-title">📋 가게 - 전체 메뉴판</h3>
                        <img id="board-img" src="" class="menu-board-img" alt="가게 메뉴판">
                    </div>
                </div>

                <div class="food-card-center">
                    <div id="food-card-target" class="food-card" onclick="toggleSidePanels()">
                        </div>
                </div>

                <div id="right-panel" class="side-panel right-slide">
                    <h2 id="store-title" class="store-title">가게 이름</h2>
                    
                    <p class="store-loc">
                        📍 지도: <a id="store-url" href="#" target="_blank" style="font-weight: bold;"></a>
                    </p>
                    
                    <div id="ai-reason" class="reason-box">추천 이유</div>
                    
                    <div id="store-notes" class="store-notes">특이사항</div>
                </div>

            </div>

            <div class="ai-chat-placeholder" style="text-align: left; background: #fff;">
                <div id="ai-chat-log" style="height: 150px; overflow-y: auto; background: #f9f9f9; border-radius: 8px; padding: 15px; margin-bottom: 10px; font-size: 14px; color: #333; border: 1px solid #eee;">
                    <div style="margin-bottom: 8px;"><strong style="color: #ff6b6b;">AI 추천봇:</strong> 오늘 점심, 어떤 메뉴를 찾으시나요? 편하게 말씀해 주세요!</div>
                </div>
                <div style="display: flex; gap: 10px;">
                    <input type="text" id="feedback-input" placeholder="예: 매운 거 말고 단백질 많은 거, 너무 비싸 등" style="flex: 1; padding: 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; outline: none;">
                    <button onclick="requestAiRecommendation()" style="background: #ff6b6b; color: white; border: none; padding: 0 20px; font-weight: bold; border-radius: 6px; cursor: pointer; transition: 0.2s;">추천받기</button>
                </div>
            </div>

        </div>
    </div>

    <div id="change-pw-zone" class="hidden" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999; display:flex; align-items:center; justify-content:center;">
        <div class="login-box" style="width:350px;">
            <h1>비밀번호 변경</h1>
            <p>새로 사용할 비밀번호를 입력하세요.</p>
            <input type="password" id="new-pw-input" placeholder="새 비밀번호" required>
            <input type="password" id="new-pw-confirm" placeholder="새 비밀번호 확인" required>
            <button onclick="attemptChangePw()">변경하기</button>
            <button onclick="toggleChangePwView(false)" style="background:#999; margin-top:5px;">취소</button>
        </div>
    </div>

    <div id="image-zoom-modal" class="hidden" onclick="closeZoomModal()" style="position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; display:flex; align-items:center; justify-content:center; cursor:zoom-out;">
        <img id="zoomed-img" src="" style="max-width:90%; max-height:90%; object-fit:contain; border-radius:10px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
    </div>

    <script>
        // PHP 백엔드 세션 감지 상태 변수
        const IS_LOGGED_IN_SERVER = <?php echo $isLoggedIn; ?>;
        const SERVER_USER_EMAIL = "<?php echo $userEmail; ?>";

        // S3 버킷 기본 주소를 선언 (끝에 꼭 슬래시 / 를 붙이기)
        const S3_BASE_URL = "<?php echo S3_BASE_URL; ?>";
        
        // 💡 [추가] Flask 백엔드 API 주소 설정
        const FLASK_API_URL = 'http://10.1.53.114:5000/api/recommend';

        // 💡 [추가] AI 추천 상태 관리 변수
        let previousFood = null;
        let rejectedFoods = [];
        const maxPrice = 20000; // 최대 예산 (필요시 UI에서 동적으로 받을 수 있음)

        const storesData = <?php echo json_encode($realStores); ?>;
        const foodsData = <?php echo json_encode($realFoods); ?>;

        window.currentFood = null;
        window.currentStore = null;

        // 문서 로드 시 세션이 있으면 즉시 메인 화면 로출
        window.addEventListener('DOMContentLoaded', () => {
            if(IS_LOGGED_IN_SERVER) {
                document.getElementById('auth-zone').classList.add('hidden');
                document.getElementById('main-page').classList.remove('hidden');
                document.getElementById('user-welcome').innerText = `${SERVER_USER_EMAIL}님 환영합니다!`;
                
                // 💡 기존의 simulate 랜덤 추천 대신, 최초 접속 AI 추천(isInitial=true)을 실행합니다.
                requestAiRecommendation(true); 
            }

            // 채팅 입력창 엔터키 지원
            const feedbackInput = document.getElementById('feedback-input');
            if (feedbackInput) {
                feedbackInput.addEventListener('keypress', function (e) {
                    if (e.key === 'Enter') requestAiRecommendation();
                });
            }
        });

        // ==========================================
        // 🔐 인증 관련 함수 모음 (변경 없음)
        // ==========================================
        function switchAuthView(viewName) {
            document.getElementById('login-box').classList.add('hidden');
            document.getElementById('register-box').classList.add('hidden');
            document.getElementById('find-id-box').classList.add('hidden');
            document.getElementById('find-pw-box').classList.add('hidden');

            if(viewName === 'login') document.getElementById('login-box').classList.remove('hidden');
            if(viewName === 'register') document.getElementById('register-box').classList.remove('hidden');
            if(viewName === 'find-id') document.getElementById('find-id-box').classList.remove('hidden');
            if(viewName === 'find-pw') document.getElementById('find-pw-box').classList.remove('hidden');
        }

        async function attemptFindId() { /* 생략 없이 기존 코드 유지 */
            const gender = document.getElementById('find-id-gender').value;
            const age = document.getElementById('find-id-age').value;
            if(!gender || !age) { alert('성별과 태어난 년도를 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'find_id', gender: gender, age: age })
            });
            const res = await response.json();
            alert(res.message);
            if(res.success) { switchAuthView('login'); }
        }

        async function attemptFindPw() { /* 기존 코드 유지 */
            const email = document.getElementById('find-pw-email').value;
            const age = document.getElementById('find-pw-age').value;
            if(!email || !age) { alert('이메일과 태어난 년도를 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'find_pw', email: email, age: age })
            });
            const res = await response.json();
            alert(res.message);
        }

        async function attemptLogin() { /* 기존 코드 유지 */
            const email = document.getElementById('login-email').value;
            const pw = document.getElementById('login-pw').value;
            if(!email || !pw) { alert('이메일과 비밀번호를 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'login', email: email, password: pw })
            });
            const res = await response.json();
            
            if(res.success) { location.reload(); } 
            else { alert(res.message); }
        }

        async function attemptRegister() { /* 기존 코드 유지 */
            const typeRadio = document.querySelector('input[name="reg-type"]:checked');
            const userType = typeRadio ? typeRadio.value : null;

            const email = document.getElementById('reg-email').value.trim();
            const pw = document.getElementById('reg-pw').value;
            const gender = document.getElementById('reg-gender').value;
            const age = document.getElementById('reg-age').value;

            if(!userType) { alert('학생인지 직원인지 선택해주세요.'); return; }
            if(!email || !pw || !gender || !age) { alert('모든 항목을 입력해주세요.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'register', user_type: userType, email: email, password: pw, gender: gender, age: age })
            });
            const res = await response.json();
            alert(res.message);
            if(res.success) { switchAuthView('login'); }
        }

        async function logout() { /* 기존 코드 유지 */
            await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'logout' }) 
            });
            location.reload();
        }

        function toggleChangePwView(show) { /* 기존 코드 유지 */
            const zone = document.getElementById('change-pw-zone');
            if(show) { zone.classList.remove('hidden'); zone.style.display = 'flex'; } 
            else { zone.classList.add('hidden'); zone.style.display = 'none'; }
        }

        async function attemptChangePw() { /* 기존 코드 유지 */
            const newPw = document.getElementById('new-pw-input').value;
            const confirmPw = document.getElementById('new-pw-confirm').value;
            
            if(!newPw || !confirmPw) { alert('비밀번호를 입력해주세요.'); return; }
            if(newPw !== confirmPw) { alert('비밀번호가 일치하지 않습니다.'); return; }

            const response = await fetch('auth.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'change_pw', new_password: newPw })
            });
            const res = await response.json();
            
            alert(res.message);
            if(res.success) { 
                toggleChangePwView(false);
                document.getElementById('new-pw-input').value = '';
                document.getElementById('new-pw-confirm').value = '';
            }
        }


        // ==========================================
        // 🤖 [핵심 추가] AI 추천 엔진 연동 로직
        // ==========================================
        
        // 채팅창 UI 업데이트 함수
        function appendChat(sender, text) {
            const chatLog = document.getElementById('ai-chat-log');
            const msg = document.createElement('div');
            msg.style.marginBottom = '8px';
            if (sender === 'user') {
                msg.innerHTML = `<strong style="color: #0068c3;">나:</strong> ${text}`;
                msg.style.textAlign = 'right';
            } else {
                msg.innerHTML = `<strong style="color: #ff6b6b;">AI:</strong> ${text}`;
            }
            chatLog.appendChild(msg);
            chatLog.scrollTop = chatLog.scrollHeight;
        }

        // Flask(app.py)로 요청을 보내고 UI를 업데이트하는 메인 함수
        async function requestAiRecommendation(isInitial = false) {
            const feedbackInput = document.getElementById('feedback-input');
            let feedback = null;

            if (!isInitial) {
                feedback = feedbackInput.value.trim();
                if(!feedback) {
                    appendChat('user', '(아무 말 없이 다른 메뉴 추천받기)');
                } else {
                    appendChat('user', feedback);
                }
                feedbackInput.value = ''; // 입력창 비우기
            }

            appendChat('bot', '가장 완벽한 메뉴를 검색 중입니다... 🔍');

            try {
                // 1. Flask 서버로 조건 전송
                const response = await fetch(FLASK_API_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        user_feedback: isInitial ? null : feedback,
                        previous_food: previousFood,
                        rejected_foods: rejectedFoods,
                        max_price: maxPrice
                    })
                });

                const data = await response.json();

                // 2. 응답 분석 및 프론트엔드 UI 업데이트
                if (data.status === 'success' || data.status === 'no_more') {
                    // 유저가 거절한 이전 음식을 블랙리스트에 추가
                    if (previousFood && !rejectedFoods.includes(previousFood) && previousFood !== data.food) {
                        rejectedFoods.push(previousFood);
                    }
                    previousFood = data.food; // 현재 추천받은 음식을 저장

                    // Flask에서 넘겨준 store_id를 이용해 PHP로 불러온 가게 원본 정보(storesData)와 매핑!
                    // 💡 [수정된 방어 코드] 가게 정보가 있으면 가져오고, 없으면 임시(기본) 데이터를 씌워 에러를 막습니다.
                    const store = storesData[data.store_id] || {
                        store_name: "알 수 없는 가게(DB 누락)",
                        location: "주소 정보 없음",
                        ggultip: "가게 꿀팁 정보가 없습니다.",
                        store_menu_url: ""
                    };

                    // 디버깅용: F12 콘솔창에서 어떤 데이터가 안 맞는지 확인하기 위해 로그를 찍어둡니다.
                    if (!storesData[data.store_id]) {
                        console.error(`🚨 [데이터 누락] DB의 stores 테이블에 store_id: ${data.store_id} 인 가게가 없습니다!`);
                    }

                    // 글로벌 변수 업데이트 (syncSidePanelsData가 읽을 수 있도록 포맷팅)
                    window.currentFood = {
                        food_name: data.food,
                        price: data.price,
                        food_image_url: data.food_image_url,
                        recommend_reason: data.recommend_reason,
                        ai_generated_tags: data.tags
                    };
                    window.currentStore = store;

                    // 3. 화면 중앙 렌더링
                    renderFoodCard();
                    // 4. 좌우 패널 렌더링
                    syncSidePanelsData(); 
                    
                    // 새 추천을 받으면 양 옆 슬라이드는 초기화(닫힘) 처리
                    document.getElementById('left-panel').classList.remove('active');
                    document.getElementById('right-panel').classList.remove('active');

                    // 5. 결과 채팅 출력
                    if (data.status === 'success') {
                        const tagList = data.tags.split(',').map(tag => `#${tag.trim()}`).join(' ');
                        appendChat('bot', `💡 오늘의 추천은 <b>[${store.store_name}]</b>의 <b>[${data.food}]</b>입니다! (${Number(data.price).toLocaleString()}원)<br><span style="font-size:13px; color:#555;">${tagList}</span>`);
                    } else {
                        appendChat('bot', `❌ 조건에 맞는 다른 메뉴가 없어 현재 메뉴를 유지합니다.<br>💡 <b>${data.food}</b>`);
                    }

                } else if (data.status === 'blocked') {
                    appendChat('bot', `🚨 ${data.reason}`);
                }
            } catch (error) {
                appendChat('bot', '🚨 AI 서버와 통신할 수 없습니다. Flask 서버가 켜져 있는지 확인해 주세요.');
                console.error(error);
            }
        }

        // 중앙 카드 렌더링 전용 함수
        function renderFoodCard() {
            if(!window.currentFood || !window.currentStore) return;
            
            const food = window.currentFood;
            const store = window.currentStore;
            let cleanImageUrl = food.food_image_url.replace(/['"]/g, '').trim();
            cleanImageUrl = cleanImageUrl.replace(/^\//, ''); // 혹시 모를 맨 앞 슬래시 제거
            
            const fullFoodImageUrl = S3_BASE_URL + cleanImageUrl;
            console.log("📸 현재 추천된 음식의 이미지 최종 주소:", fullFoodImageUrl);

            const targetBox = document.getElementById('food-card-target');
            targetBox.innerHTML = `
                <img src="${fullFoodImageUrl}" alt="${food.food_name}" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&q=80'">
                <div class="food-info">
                    <h2 class="food-title">${store.store_name}<br>추천 메뉴 : ${food.food_name}</h2>
                    <div class="food-price">${Number(food.price).toLocaleString()} 원</div>
                    <span class="click-hint">🔍 메뉴 사진을 클릭하면 좌우로 상세 정보가 열립니다!</span>
                </div>
            `;
        }

        // ==========================================
        // 📊 좌우 패널 데이터 동기화 (기존 로직 유지 및 개선)
        // ==========================================
        function syncSidePanelsData() {
            if(!window.currentFood || !window.currentStore) return;
            const store = window.currentStore;
            const food = window.currentFood;

            // 좌측: 메뉴판 세팅
            document.getElementById('board-title').innerText = `📋 ${store.store_name} - 메뉴판`;
            document.getElementById('board-img').src = S3_BASE_URL + store.store_menu_url;

            // 우측: 1. 상호
            document.getElementById('store-title').innerText = store.store_name;
            
            // 우측: 2. 지도 바로가기 링크 세팅
            const urlElem = document.getElementById('store-url');
            urlElem.innerText = `${store.store_name} 바로가기`; 
            let linkUrl = store.location; 

            if (linkUrl && linkUrl.trim() !== "") {
                if (!linkUrl.startsWith('http')) { linkUrl = 'https://' + linkUrl; }
                urlElem.href = linkUrl;
                urlElem.onclick = null; 
            } else {
                urlElem.href = "#";
                urlElem.onclick = function(e) {
                    e.preventDefault(); 
                    alert("아직 등록된 지도 링크가 없습니다.");
                };
            }
            
            // 우측: 3. 추천 이유 (Flask가 넘겨준 AI 데이터 매핑)
            document.getElementById('ai-reason').innerHTML = `<strong>💡 추천 이유:</strong><br>${food.recommend_reason}`;
            
            // 우측: 4. 꿀팁 (특이사항)
            document.getElementById('store-notes').innerHTML = `<strong>🍯 꿀팁:</strong><br>${store.ggultip}`;
        }

        function toggleSidePanels() {
            const leftPanel = document.getElementById('left-panel');
            const rightPanel = document.getElementById('right-panel');

            if(leftPanel.classList.contains('active')) {
                leftPanel.classList.remove('active');
                rightPanel.classList.remove('active');
            } else {
                syncSidePanelsData();
                leftPanel.classList.add('active');
                rightPanel.classList.add('active');
            }
        }

        // 확대 이미지 모달 처리
        document.getElementById('board-img').addEventListener('click', function() {
            const zoomModal = document.getElementById('image-zoom-modal');
            const zoomedImg = document.getElementById('zoomed-img');
            zoomedImg.src = this.src; 
            zoomModal.classList.remove('hidden'); 
        });

        function closeZoomModal() {
            document.getElementById('image-zoom-modal').classList.add('hidden');
        }
    </script>
</body>
</html>