from flask import Flask, request, jsonify
from flask_cors import CORS
from google import genai
import mysql.connector
import json
import random
import boto3
import math

app = Flask(__name__)
CORS(app)

# ==========================================
# 🔐 보안 및 설정
# ==========================================
# 본인의 API 키를 입력해 주세요.
client = genai.Client(api_key="")

def get_db_connection():
    return mysql.connector.connect(
        host="localhost", 
        user="root",
        password="1234",
        database="wft",
        port=2102
    )

@app.route('/api/recommend', methods=['POST'])
def recommend_api():
    data = request.json
    user_feedback = data.get('user_feedback', None)
    previous_food = data.get('previous_food', None)
    rejected_foods = data.get('rejected_foods', [])
    max_price = data.get('max_price', 20000)

    conn = get_db_connection()
    # 💡 [핵심 수정 1] 딕셔너리 형태로 데이터를 가져와 프론트엔드와 쉽게 맞물리게 합니다.
    cursor = conn.cursor(dictionary=True) 

    try:
        # --------------------------------------------------------
        # [분기 1] 최초 추천 (피드백이 없는 상태)
        # --------------------------------------------------------
        if user_feedback is None:
            print(f"\n🎲 [최초 추천] 예산 {max_price}원 이하 메뉴 중 랜덤 추천...")
            # 💡 [핵심 수정 2] 프론트엔드가 요구하는 모든 컬럼을 조회합니다.
            query = "SELECT store_id, food_name, price, ai_generated_tags, food_image_url, recommend_reason FROM foods WHERE price <= %s"
            cursor.execute(query, (max_price,))
            rows = cursor.fetchall()
            
            if not rows: 
                return jsonify({"status": "no_more", "reason": "예산에 맞는 메뉴가 없습니다."})
            
            selected = random.choice(rows)
            print(f"💡 오늘의 추천 메뉴: {selected['food_name']} ({selected['price']}원)")
            
            # 💡 [핵심 수정 3] JSON 응답에 store_id, food_image_url 등을 모두 포함합니다.
            return jsonify({
                "status": "success", 
                "store_id": selected['store_id'],
                "food": selected['food_name'], 
                "price": selected['price'],
                "tags": selected['ai_generated_tags'], 
                "food_image_url": selected['food_image_url'],
                "recommend_reason": selected['recommend_reason']
            })

        # --- 아래부터는 명시적인 피드백(공백 포함)이 들어온 상황 ---
        if previous_food and previous_food not in rejected_foods:
            rejected_foods.append(previous_food)

        # --------------------------------------------------------
        # [분기 2] 공백 엔터 ("") 대응 -> 남은 것 중 무작위 랜덤
        # --------------------------------------------------------
        if user_feedback.strip() == "":
            print(f"\n🎲 [랜덤 대안] 특별한 이유 없이 넘기셨습니다. 남은 메뉴 중 고릅니다...")
            
            format_strings = ', '.join(['%s'] * len(rejected_foods)) if rejected_foods else "''"
            query = f"""
                SELECT store_id, food_name, price, ai_generated_tags, food_image_url, recommend_reason 
                FROM foods 
                WHERE price <= %s AND food_name NOT IN ({format_strings})
            """
            
            params = [max_price] + rejected_foods if rejected_foods else [max_price]
            cursor.execute(query, tuple(params))
            rows = cursor.fetchall()
            
            if not rows: 
                return jsonify({"status": "no_more", "food": previous_food, "reason": "조건에 맞는 대안이 없습니다."})
            
            selected = random.choice(rows)
            print(f"💡 [랜덤 대안 추천]: {selected['food_name']} ({selected['price']}원)")
            
            return jsonify({
                "status": "success", 
                "store_id": selected['store_id'],
                "food": selected['food_name'], 
                "price": selected['price'],
                "tags": selected['ai_generated_tags'], 
                "food_image_url": selected['food_image_url'],
                "recommend_reason": selected['recommend_reason']
            })

        # --------------------------------------------------------
        # [분기 3] 정상 피드백 처리 및 키워드 추출
        # --------------------------------------------------------
        integrated_prompt = f"""Input: "{user_feedback}"

1. If the input is completely unrelated to food or dining, set "is_food": false.
2. If there are negative expressions, convert them into positive opposite traits for the query (e.g., "not hot" -> "cold").
3. The "query" value MUST be in Korean.

Output ONLY a valid JSON object in this exact format:
{{"is_food": true/false, "query": "Korean keyword"}}"""
        
        # 💡 [핵심 수정 4] 존재하지 않는 lite 모델 대신 최신 2.5-flash 모델을 사용합니다.
        ai_response = client.models.generate_content(model='gemini-3.1-flash-lite', contents=integrated_prompt)
        raw_text = ai_response.text.strip()
        
        # 마크다운 방어 로직
        if raw_text.startswith("```json"): 
            raw_text = raw_text.replace("```json", "").replace("```", "").strip()
        elif raw_text.startswith("```"): 
            raw_text = raw_text.replace("```", "").strip()
        
        result = json.loads(raw_text)
        
        if not result.get("is_food", True):
            return jsonify({
                "status": "blocked", 
                "food": previous_food, 
                "reason": "음식과 무관한 입력입니다. 다시 말씀해 주세요."
            })

        # --------------------------------------------------------
        # [분기 4] 구글 임베딩 변환 및 MariaDB 벡터 검색
        # --------------------------------------------------------
        new_search_query = result.get("query", "맛있는 점심")
        
        embed_response = client.models.embed_content(model='gemini-embedding-001', contents=new_search_query)
        search_vector = embed_response.embeddings[0].values
        
        truncated_search = search_vector[:768]
        magnitude = math.sqrt(sum(x**2 for x in truncated_search))
        normalized_search = [x / magnitude for x in truncated_search]
        
        vector_str = json.dumps(normalized_search)

        # 💡 [핵심 수정 5] 벡터 검색 쿼리에도 store_id와 추천 이유를 포함시킵니다.
        if rejected_foods:
            format_strings = ', '.join(['%s'] * len(rejected_foods))
            query = f"""
                SELECT store_id, food_name, price, ai_generated_tags, food_image_url, recommend_reason
                FROM foods 
                WHERE price <= %s AND food_name NOT IN ({format_strings})
                ORDER BY VEC_DISTANCE_COSINE(embedding, VEC_FromText(%s)) 
                LIMIT 1;
            """
            params = [max_price] + rejected_foods + [vector_str]
        else:
            query = """
                SELECT store_id, food_name, price, ai_generated_tags, food_image_url, recommend_reason
                FROM foods 
                WHERE price <= %s
                ORDER BY VEC_DISTANCE_COSINE(embedding, VEC_FromText(%s)) 
                LIMIT 1;
            """
            params = [max_price, vector_str]

        cursor.execute(query, tuple(params))
        best_match = cursor.fetchone()

        if best_match:
            return jsonify({
                "status": "success", 
                "store_id": best_match['store_id'],
                "food": best_match['food_name'], 
                "price": best_match['price'],
                "tags": best_match['ai_generated_tags'],
                "food_image_url": best_match['food_image_url'],
                "recommend_reason": best_match['recommend_reason']
            })
        else:
            return jsonify({"status": "no_more", "food": previous_food, "reason": "조건에 맞는 대안이 없습니다."})

    except Exception as e:
        print(f"🚨 서버 에러: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)